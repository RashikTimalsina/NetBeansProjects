-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2017 at 06:37 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ccidb`
--

-- --------------------------------------------------------

--
-- Table structure for table `mytb`
--

CREATE TABLE IF NOT EXISTS `mytb` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbregister`
--

CREATE TABLE IF NOT EXISTS `tbregister` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbregister`
--

INSERT INTO `tbregister` (`username`, `password`, `fname`, `lname`) VALUES
('ram', 'ram', 'ram', 'ram'),
('3', 'Milan', 'milan', 'mila'),
('ram', 'ram', 'ram', 'ram'),
('ram', 'ram', 'ram', 'ram'),
('khan', 'khan', 'khan', 'khan'),
('milan', 'milan', 'milan', 'milan'),
('test', 'test', 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `tbteacher`
--

CREATE TABLE IF NOT EXISTS `tbteacher` (
  `tid` int(11) NOT NULL,
  `tfname` varchar(100) DEFAULT NULL,
  `tlname` varchar(100) DEFAULT NULL,
  `taddress` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbteacher`
--

INSERT INTO `tbteacher` (`tid`, `tfname`, `tlname`, `taddress`) VALUES
(1, 'shyam', 'chaudhary', 'mumbai'),
(3, 'Tilak', 'ABC', 'pkh'),
(4, 'Yathartha', 'Tamrakar', 'NewRoad'),
(5, 'a', 'a', 'a');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
